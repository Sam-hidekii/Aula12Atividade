__author__ = 'Samuel Assis'
#===================================================
#Conversor
print('~~~Conversor de Metros para Centímetros~~~\n')
m = float(input("Insira quantos Metros você quer converter: ").replace(',','.'))
cm = (m*100)
print('Resultado em centímetros: ',cm)

print('\n\n................................................\n')
#===================================================
#Média
print('~~~Média das Notas~~~\n')
a = float(input('Digite sua primeira nota: '))
b = float(input('\nDigite sua quarta nota: '))
c = float(input('\nDigite sua terceira nota: '))
d = float(input('\nDigite sua última nota: '))

media = (a+b+c+d)/4
print('\nA média é: ',media)
print('\n\n................................................\n')